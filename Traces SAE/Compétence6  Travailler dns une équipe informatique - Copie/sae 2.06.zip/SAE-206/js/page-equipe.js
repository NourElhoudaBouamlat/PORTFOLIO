let a=document.querySelectorAll('.membre');
let texte=document.querySelectorAll('.texte');
for(let i=0;i<texte.length;i++){
  texte[i].addEventListener('mouseover',function(event){
    let index=Array.from(texte).indexOf(event.currentTarget);
    console.log(index);
    for(let j=0;j<texte.length;j++){
      if (index===0 && index===j){
       texte[index].textContent="Mail: latifmarya@gmail.com. \n"+
       "Agée de 19ans, actuellement elle est étudiante en BUT1 Informatique à l'iut de Villetaneuse université Sorbonne Paris Nord.";
      }
    else if (index===1 && index===j ){
      texte[index].textContent="Mail: n.bouamlat20@gmail.com. \n"+
      "Agée de 18ans, actuellement elle est étudiante en BUT1 Informatique à l'iut de Villetaneuse université Sorbonne Paris Nord.";
    }
    else if (index===2 && index===j){
      texte[index].textContent="Mail: indiacabo@gmail.com. \n"+
      "Agée de 19ans, actuellement elle est étudiante en BUT1 Informatique à l'iut de Villetaneuse université Sorbonne Paris Nord.";
    }
    else if (index===3 && index===j){
      texte[index].textContent="Mail: medani.lina2004@gmail.com.\n"+
      "Agée de 19ans, actuellement elle est étudiante en BUT1 Informatique à l'iut de Villetaneuse université Sorbonne Paris Nord.";
    }
    else if (index===4 && index===j){
      texte[index].textContent="Mail: aboubakar.baouchi@gmail.com.\n"+
      "Agé de 19ans, actuellement il est étudiant en BUT1 Informatique à l'iut de Villetaneuse université Sorbonne Paris Nord.";
    }
    else if (index===5 && index===j){
      texte[index].textContent="Mail: hibaoumsid2@gmail.com.\n"+
      "Agée de 19ans, actuellement elle est étudiante en BUT1 Informatique à l'iut de Villetaneuse université Sorbonne Paris Nord.";
    }}})

  texte[i].addEventListener('mouseleave',function(){
     texte[0].textContent="Depuis le début du projet Marya est responsable sur son avancement, elle a planifié les taches et les étapes. On s'est toujours dirigé vers elle pour prendre les décisions finaux ou bien pour proposer des solutions en cas de blocage.";
     texte[1].textContent="Nour a participé pour faire le design et le contenu de la version 2024 de ce musée. Elle a aussi fait partie de la réalisation du code javascript de notre site.";
     texte[2].textContent="India a fait la version 2024 de notre site dont le design et le contenu. Ainsi, elle a participé à la réalisation du code html du site.";
     texte[3].textContent="Lina a réalisé le prototype de la page d’équipe, elle a rédigé les différentes missions de chaque membre de l’équipe. Elle a fait le prototype de la page denotre équipe et elle a participé au codage du site en javascript.";
     texte[4].textContent="Aboubakar est responsable sur le prototype de la page d’évènement dont le design et les informations présentées dans la page. Ainsi, il a participé à la réalisation du code javascript de ce site.";
     texte[5].textContent="Hiba a participé à la prise des photos mises sur le site et elle recherché les informations utiles pour le site. Ainsi, elle a aidé dans la réalisation du code html du site.";
})}
