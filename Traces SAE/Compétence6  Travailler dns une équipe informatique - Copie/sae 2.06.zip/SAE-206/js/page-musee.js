let retour=document.getElementById('retour');
let img = document.querySelectorAll('.card-img');
let card = document.querySelectorAll('.card');
let index;
let description = document.getElementById('description');
let openCard = document.getElementById('open-card');
let sourceIMG = ["../asset/page-musee/naissanceOpera.jpeg","../asset/page-musee/epoqueLumiere.jpeg","../asset/page-musee/romantique.jpeg","../asset/page-musee/electroGuitare.jpeg","../asset/page-musee/musqiueMonde.jpeg","../asset/page-musee/expo2024.jpeg"];
let image = document.getElementById('image');
let titre = document.getElementById('titre');
let titre_stock = ["NAISSANCE DE L’OPÉRA ","LA MUSIQUE DES LUMIÈRES","L’EUROPE ROMANTIQUE","L’ACCÉLÉRATION DE L’HISTOIRE…","LES MUSIQUES DU MONDE","EXPO 2024"]
let texte = ["Le parcours débute en Italie avec la maquette de la salle du palais de Mantoue où fut représenté en 1607. L’Orfeo de Claudio Monteverdi, considéré comme le premier opéra de l’histoire. Une collection unique d’instruments témoigne des pratiques musicales de l’époque : claviers, luths, cornets à bouquin, cistres.<br/><br/>Au château de Versailles, Louis XIV favorise l’épanouissement de la musique baroque. La tragédie lyrique, les défilés militaires et le rituel de la chasse coexistent avec des pratiques musicales plus intimes, illustrées par une importante collection de guitares baroques, de violes de gambe et de clavecins flamands et français.",
"Au XVIIIe siècle, en France, la musique quitte peu à peu la cour. L’opéra, principale institution musicale, devient le siège de querelles esthétiques tandis que les salons des aristocrates et bourgeois cultivés favorisent l’essor de la musique instrumentale. On y joue du clavecin, de la harpe… L’époque est également marquée par une vision idéalisée de la nature, qui fait naître au sein des sociétés cultivées la vogue des musiques pastorales, recourant aux musettes et aux vielles à roue. <br/>L’évolution du goût musical vers une plus grande expressivité favorise l’apparition d’un nouvel instrument, le piano-forte. Les concerts publics se développent, dont ceux du Concert Spirituel, et accueillent des musiciens étrangers renommés comme Joseph Haydn et Wolfgang Amadeus Mozart.",
"Le langage musical du XIXe siècle s’imprègne des idées portées par le courant artistique romantique. L’expression des sentiments, l’affirmation de soi et l’attrait pour le fantastique le caractérisent. Le jeu du soliste, servi notamment par les violons de Stradivari dont le Musée possède plusieurs exemplaires, et l’essor de l’orchestre symphonique constituent les deux pôles de la musique instrumentale. <br/>Les compositeurs et pianistes virtuoses Franz Liszt et Frédéric Chopin, liés aux facteurs de pianos Érard et Pleyel, incarnent la figure du musicien romantique. Motivés par les besoins croissants en termes de timbres et de puissance des orchestres, notamment ceux d’Hector Berlioz et de Richard Wagner, de nouveaux instruments voient le jour : l’octobasse, le saxophone, le tuba wagnérien…",
"L’œuvre Ionisation (1931) d’Edgard Varèse illustre combien la percussion ouvre un champ sonore inédit au XXe siècle. L’apparition de l’électricité révolutionne également la musique avec l’invention de nouveaux instruments, notamment par Léon Theremin, Maurice Martenot ou Laurens Hammond. <br/>Le bouleversement technologique des outils analogiques puis numériques est représenté au Musée par le synthétiseur modulaire de Frank Zappa, la machine Upic de Iannis Xenakis ou l’ordinateur 4X développé par l’Ircam. Les musiques populaires ont pleinement profité de ces révolutions techniques. Une galerie consacrée à la guitare électrique présente des modèles mythiques de guitares et basses de Fender, Gibson ou Rickenbecker.",
"Comme en Occident, la diversité des traditions musicales qui se sont développées à travers le monde résulte d’une histoire profonde, faite de rencontres, de convergences et d’emprunts. Transmises le plus souvent oralement, ces traditions préservent un héritage musical qui joue un rôle majeur dans l’organisation sociale et religieuse de leurs communautés.<br/>Organisée en cinq aires distinctes (monde arabe, Asie, Afrique, Océanie et cultures amérindiennes), la présentation des instruments est enrichie d’extraits audiovisuels permettant au visiteur d’appréhender les spécificités culturelles de certaines traditions dans leur contexte ou de découvrir de très rares instruments et des répertoires méconnus."
]

for (let i = 0;i<card.length;i++) {
        card[i].addEventListener('click',function(e){
            index = Array.from(card).indexOf(e.currentTarget);
            console.log(index);
            for (let j = 0;j<card.length;j++) {
                card[j].className='cible';
            }
            retour.style.display="block";
            showOpenCard();
            description.innerHTML=texte[index];
            titre.textContent=titre_stock[index];
            image.src=sourceIMG[index];
    })
}

retour.addEventListener('click',function(){
    let cible=document.querySelectorAll('.cible');
    for (let k = 0;k<cible.length;k++) {
        cible[k].className='card';
    }
    retour.style.display="none";
    openCard.style.display='none';
    openCard.style.transform = 'scale(0.3)';
})

let positionList = ["25% 25%","50% 25%","75% 25%","25% 75%","50% 75%","75% 75%"];
openCard.style.transition = `transform 0.5s ease-in-out`;
openCard.style.opacity = 0;  
openCard.style.transform = 'scale(0.3)';

function showOpenCard() {
  openCard.style.transformOrigin = positionList[index];
  openCard.style.display = 'flex'; 
  setTimeout(() => {
    openCard.style.opacity = 1; 
    openCard.style.transform = 'scale(1)';
  }, 50);
}
